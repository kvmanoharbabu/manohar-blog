package com.app.selectmultipleimage

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.app.selectmultipleimage.databinding.ActivityMainBinding

class MainActivity() : AppCompatActivity(), View.OnClickListener {
    var list: ArrayList<Uri>? = null
    var adaptor: RecyclerAdapter? = null
    lateinit var binding: ActivityMainBinding

    var colum = arrayOf(
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.READ_EXTERNAL_STORAGE
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        list = ArrayList()
        adaptor = RecyclerAdapter(list!!)
        binding.recyclerView.setLayoutManager(GridLayoutManager(this@MainActivity, 4))
        binding.recyclerView.setAdapter(adaptor)
        adaptor = RecyclerAdapter(list!!)
        binding.recyclerView.setLayoutManager(GridLayoutManager(this@MainActivity, 4))
        binding.recyclerView.setAdapter(adaptor)
        val callback: ItemTouchHelper.Callback = RecyclerRowMoveCallback(adaptor)
        val touchHelper = ItemTouchHelper(callback)
        touchHelper.attachToRecyclerView(binding.recyclerView)

        binding.recyclerView.setAdapter(adaptor)
        binding.button.setOnClickListener(this)
        if (ActivityCompat.checkSelfPermission(
                this, colum[0]
            ) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this, colum[1]
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(colum, 123)
            }
        }
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.button -> openGalley()
        }
    }

    private fun openGalley() {
        val intent = Intent()
        intent.type = "image/*"
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(Intent.createChooser(intent, "Selcet Picture"), 123)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 123 && resultCode == RESULT_OK) {
            if (data!!.clipData != null) {
                val x = data.clipData!!.itemCount
                for (i in 0 until x) {
                    list!!.add(data.clipData!!.getItemAt(i).uri)
                }
                adaptor!!.notifyDataSetChanged()
                binding.textView.text = "Image(" + list!!.size + ")"
            } else if (data.data != null) {
                val imgurl = data.data!!.path
                list!!.add(Uri.parse(imgurl))
            }
        }
    }
}
